package net.eclipce.transpondersnails.block.entity;

import net.eclipce.transpondersnails.item.DenDenMushiItem;
import net.eclipce.transpondersnails.item.ModItems;
import net.eclipce.transpondersnails.screen.DialingMenu;
import net.eclipce.transpondersnails.voice.server.TransponderCallManager;
import net.eclipce.transpondersnails.voice.server.CallSoundManager;
import net.eclipce.transpondersnails.voice.server.CallSession;
import net.eclipce.transpondersnails.voice.VoiceChatConstants;
import net.eclipce.transpondersnails.visual.VisualCallConstants;
import net.eclipce.transpondersnails.visual.VisualCallState;
import net.eclipce.transpondersnails.visual.VisualInteraction;
import net.eclipce.transpondersnails.visual.StreamPresets;
import net.eclipce.transpondersnails.visual.VisualCameraPositions;
import net.eclipce.transpondersnails.visual.VisualStreamNames;
import net.eclipce.transpondersnails.visual.server.VisualStreamManager;
import net.eclipce.transpondersnails.visual.server.VisualTapManager;
import net.eclipce.transpondersnails.visual.VisualRoles;
import net.eclipce.transpondersnails.visual.VisualScreenConfig;
import net.eclipce.transpondersnails.visual.VisualSettings;
import net.eclipce.transpondersnails.visual.VisualSnailRole;
import net.eclipce.transpondersnails.visual.server.VisualCallManager;
import net.eclipce.transpondersnails.visual.server.VisualProjectorConfig;
import net.eclipce.transpondersnails.visual.server.VisualSnailRegistry;
import net.eclipce.transpondersnails.TransponderSnails;
import net.eclipce.transpondersnails.block.ModBlocks;
import net.eclipce.transpondersnails.block.custom.TransponderSnailBlock;
import net.eclipce.transpondersnails.data.SnailKind;
import net.eclipce.transpondersnails.data.SnailNumberRegistry;
import net.eclipce.transpondersnails.network.ModPackets;
import net.eclipce.transpondersnails.network.packets.SnailNumberSyncPacket;
import net.eclipce.transpondersnails.network.packets.CallStateSyncPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class TransponderSnailBlockEntity extends BlockEntity implements MenuProvider, CallSoundManager.BlockstateUpdateCallback {

    // Add these static fields to track global state
    private static boolean isServerShuttingDown = false;
    private static final Set<BlockPos> processedPositions = ConcurrentHashMap.newKeySet();

    private UUID activeCallId;
    private boolean isRinging = false;
    private String dialedNumber = "";

    // Snail identity - persisted directly in the block entity
    public UUID snailUUID = null;
    public int assignedSnailNumber = -1;
    public boolean initialized = false;
    private boolean needsValidation = false;

    // Call state tracking
    private CallStateSyncPacket.CallState currentCallState = CallStateSyncPacket.CallState.IDLE;
    private long ringStartTime = 0;

    // Visual state tracking for blockstates
    private boolean hasAmbientSound = false;
    private boolean inActiveCall = false;
    private long lastBlockstateUpdate = 0;

    // Instance fields for lifecycle tracking
    private boolean isUnloading = false;
    private boolean hasBeenLoaded = false;
    private boolean validationCompleted = false;

    // CallSession integration
    private CallSession currentCallSession = null;

    // Audio readiness tracking
    private boolean audioReady = false;

    // Snail color data
    public int bodyColor = -1; // RGB color for snail body (-1 = uninitialized)
    public int shellColor = 0; // Dye color index (0-15, default white)
    public boolean colorsInitialized = false;

    // UV mask texture path for eye protection
    private static final ResourceLocation UV_MASK_TEXTURE =
            new ResourceLocation("transpondersnails:block/transpondersnail/snail/transponder_snail_uv_mask");

    // Whether this snail has a Snail Number: true for the phone snails and for the Visual Transponder Snail (the projector, which
    // draws from the same pool but is a different KIND, see SnailKind); false for the Visual Transmitter (camera) and the Amplified
    // Transponder Snail. Only phone snails register with the (phone) call manager; visual snails never do.
    private final boolean hasSnailNumber;

    // ---- Visual Transponder Snail (video calls) ----
    // True for both placed visual snails. The projector has a snail number of the VISUAL kind and is dialed with the same dialing GUI as a
    // phone (VisualCallManager#dial); the camera has no number and VisualCallManager pairs it with the nearest idle projector in range.
    // The call state is NOT persisted (calls only exist in memory).
    private final boolean isVisualSnail;
    private volatile VisualCallState visualCallState = VisualCallState.IDLE;
    private volatile boolean visualAudioActive = false;

    // ---- streams ----
    // A Visual Transmitter (camera) broadcasts a STREAM; a Visual Transponder Snail (projector) tunes to one and keeps three presets.
    private UUID streamId;                       // camera: the stable identity of its stream (it stays when the stream is off, so presets can find it)
    private String streamName = "";              // camera: the name its owner gave it; blank = "<owner>'s Stream"
    private UUID ownerId;                        // who placed it last
    private String ownerName = "";
    private volatile boolean streaming = false;  // camera: on air right now. Not saved: after a restart every stream is off.
    private final StreamPresets presets = new StreamPresets(); // projector: its three saved streams
    /** Game time of the last click that switched the stream on or off (so a hammered button does not toggle it every tick). */
    public long lastStreamToggleTick = -100L;
    // Projector settings (changed in the settings menu). Persisted and synced to clients.
    // PREFERRED side length (in blocks) of the square the video is projected as. What is actually shown is this size held inside the
    // zoom range for the distance to the screen (see ProjectorZoom), so it is only a preference.
    private int screenSize = VisualCallConstants.SCREEN_DEFAULT_SIZE;
    // Where the screen sits relative to its default place, in blocks (quarter steps), as seen by a viewer standing in front of the
    // snail: side + = to the viewer's right (max +-3), up + = up (max +-3), back = extra distance further BACK from the snail
    // (0 .. 3, never towards it; only used while there is no surface behind the snail to project onto - otherwise the depth is automatic).
    private float screenOffsetSide = 0.0F;
    private float screenOffsetUp = 0.0F;
    private float screenOffsetBack = 0.0F;

    public TransponderSnailBlockEntity(BlockPos pPos, BlockState pBlockState) {
        super(ModBlockEntities.TRANSPONDER_SNAIL_BE.get(), pPos, pBlockState);

        Block block = pBlockState.getBlock();
        // Both visual snails - the projector (Visual Transponder Snail) and the camera (Visual Transmitter Transponder Snail) -
        // are recognised by their registry name (see VisualRoles). The projector has a number (of its own kind), the camera has none.
        VisualSnailRole role = VisualRoles.of(block);
        this.isVisualSnail = role != null;
        this.hasSnailNumber = role == VisualSnailRole.DUPLEX
                || (role == null && block != ModBlocks.AMPLIFIED_TRANSPONDER_SNAIL.get());
    }

    /** Which kind of number this snail holds: the projector's is VISUAL, every other numbered snail is a phone. */
    private SnailKind snailKind() {
        return isVisualSnail ? SnailKind.VISUAL : SnailKind.PHONE;
    }

    /**
     * Whether this snail block has a Snail Number and is dialable: the phone snails and the Visual Transponder Snail (projector).
     * False for the Visual Transmitter (camera) and the Amplified Transponder Snail.
     */
    public boolean hasSnailNumber() {
        return hasSnailNumber;
    }

    // =================== VISUAL TRANSPONDER SNAIL (VIDEO CALLS) ===================

    /** True for the placed Visual Transponder Snail (projector) and Visual Transmitter Transponder Snail (camera): video calls, no snail number. */
    public boolean isVisualSnail() {
        return isVisualSnail;
    }

    public int getScreenSize() {
        return screenSize;
    }

    public float getScreenOffsetSide() {
        return screenOffsetSide;
    }

    public float getScreenOffsetUp() {
        return screenOffsetUp;
    }

    public float getScreenOffsetBack() {
        return screenOffsetBack;
    }

    /**
     * Applies new projector settings (screen size and offsets). Every value is clamped / snapped here, so it is safe to pass
     * whatever a client sent. Stores them and syncs them to all clients.
     *
     * @return true if anything changed
     */
    public boolean setScreenConfig(int size, float side, float up, float back) {
        int newSize = VisualScreenConfig.clampSize(size, VisualSettings.maxScreenSize());
        float newSide = VisualScreenConfig.snapOffset(side);
        float newUp = VisualScreenConfig.snapOffset(up);
        float newBack = VisualScreenConfig.snapBack(back); // never negative: the screen cannot be moved towards the snail
        if (newSize == screenSize && newSide == screenOffsetSide && newUp == screenOffsetUp && newBack == screenOffsetBack) {
            return false;
        }
        this.screenSize = newSize;
        this.screenOffsetSide = newSide;
        this.screenOffsetUp = newUp;
        this.screenOffsetBack = newBack;
        setChanged();
        if (level != null && !level.isClientSide()) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
        }
        return true;
    }

    public VisualCallState getVisualCallState() {
        return visualCallState;
    }

    // ---------------- streams ----------------

    /** The id of this camera's stream; made the first time it is asked for. */
    public UUID getOrCreateStreamId() {
        if (streamId == null) {
            streamId = UUID.randomUUID();
            setChanged();
        }
        return streamId;
    }

    public String getStreamName() {
        return streamName;
    }

    /** Names the stream (blank = back to "<owner>'s Stream"). */
    public void setStreamName(String name) {
        String clean = VisualStreamNames.sanitize(name);
        if (clean.equals(streamName)) return;
        streamName = clean;
        setChanged();
    }

    /** What the stream is called: its own name, or "Steve's Stream". */
    public String getStreamDisplayName() {
        return VisualStreamNames.displayName(streamName, ownerName);
    }

    @Nullable
    public UUID getOwnerId() {
        return ownerId;
    }

    public String getOwnerName() {
        return ownerName;
    }

    /** The player who placed this snail is its owner (a visual snail only; the owner names a stream). */
    public void setOwner(Player player) {
        if (!isVisualSnail || player == null) return;
        ownerId = player.getUUID();
        ownerName = VisualStreamNames.sanitize(player.getGameProfile().getName());
        setChanged();
    }

    /** For a snail that has no owner yet (placed before owners existed): the player who first uses it becomes its owner. */
    public void setOwnerIfAbsent(Player player) {
        if (ownerId == null) setOwner(player);
    }

    public boolean isStreaming() {
        return streaming;
    }

    /**
     * Switches the stream on or off (server thread, VisualStreamManager). The eyes go to the "in call" model while it is live, whether or
     * not anybody is watching: the camera never shows who is.
     */
    public void setStreaming(boolean on) {
        if (!isVisualSnail || this.streaming == on) return;
        this.streaming = on;
        setVisualCallState(on ? VisualCallState.CONNECTED : VisualCallState.IDLE);
    }

    /** A projector's three saved streams. */
    public StreamPresets getPresets() {
        return presets;
    }

    /** Called by VisualCallManager (server thread). Refreshes the idle / sound / call / active model. */
    public void setVisualCallState(VisualCallState state) {
        if (!isVisualSnail) {
            return;
        }
        this.visualCallState = state;
        if (state == VisualCallState.IDLE) {
            this.visualAudioActive = false;
        }
        updateBlockstateVisuals();
    }

    /** Called by VisualCallManager (server thread): audio is currently being played at this snail. */
    public void setVisualAudioActive(boolean active) {
        if (!isVisualSnail || this.visualAudioActive == active) {
            return;
        }
        this.visualAudioActive = active;
        updateBlockstateVisuals();
    }

    /**
     * Same four models as the numbered snails:
     * idle = "transponder_snail", sound = "transponder_snail_sound", call = "transponder_snail_call",
     * active = "transponder_snail_active". hasAmbientSound is still driven by CallSoundManager (ring tone,
     * connected / disconnected / busy sounds), exactly as for numbered snails.
     */
    private String determineVisualModel() {
        switch (visualCallState) {
            case RINGING_IN:
                return "transponder_snail_sound";
            case CONNECTING:
                return "transponder_snail_call";
            case CONNECTED:
                return (visualAudioActive || hasAmbientSound) ? "transponder_snail_active" : "transponder_snail_call";
            case CALLING_OUT:
                return "transponder_snail";
            case IDLE:
            default:
                return hasAmbientSound ? "transponder_snail_sound" : "transponder_snail";
        }
    }

    /**
     * Right click / sneak + right click on a Visual Transponder Snail.
     * Sneak + right click while idle cycles the projected screen size; everything else goes to VisualCallManager.
     */
    private InteractionResult handleVisualInteraction(ServerPlayer player, boolean isSneaking) {
        // The projector works like a phone snail: it gets its number the first time it is used, and right click opens the same dialing GUI.
        // The camera has no number and no GUI: a click starts / stops its stream, crouch + click opens its status menu. See VisualInteraction
        // for the whole table: crouch + right click on an IDLE projector is the ONLY way to the projector settings.
        boolean projector = VisualRoles.ofEntity(this) == VisualSnailRole.DUPLEX;
        boolean inCall = false;
        if (projector) {
            ensureSnailNumberAssigned(player);
            VisualCallManager calls = VisualCallManager.peek();
            inCall = calls != null && level != null && calls.isInCall(GlobalPos.of(level.dimension(), worldPosition));
        }

        // A projector wired to a Black Transponder Snail is its display: no dialing GUI, nothing to answer; its settings still open.
        boolean tapped = projector && level != null && VisualTapManager.isTapped(level, worldPosition);
        switch (VisualInteraction.decide(projector, isSneaking, inCall, tapped)) {
            case TAP_BLOCKED:
                player.displayClientMessage(Component.literal("Connected to a Black Transponder Snail")
                        .withStyle(net.minecraft.ChatFormatting.GRAY), true);
                return InteractionResult.SUCCESS;
            case OPEN_SETTINGS:
                VisualProjectorConfig.open(player, this);
                return InteractionResult.SUCCESS;
            case OPEN_DIALER:
                openVisualDialing(player);
                return InteractionResult.SUCCESS;
            case OPEN_STATUS:
                VisualStreamManager.openStatus(player, this);
                return InteractionResult.SUCCESS;
            case STREAM_TOGGLE:
                VisualStreamManager.toggle(player, this);
                return InteractionResult.SUCCESS;
            default:
                break; // a call: answered, hung up, or placed by the camera
        }

        VisualCallManager manager = VisualCallManager.get();
        if (manager == null) {
            player.displayClientMessage(
                    Component.literal("Voice chat system not available!")
                            .withStyle(net.minecraft.ChatFormatting.RED),
                    true
            );
            return InteractionResult.FAIL;
        }

        return manager.onInteract(player, this);
    }

    /**
     * Opens the dialing GUI for this visual snail. The client does not otherwise learn which block opened the menu, so it is sent along:
     * the same two fields a handheld phone sends, then (new) a flag and the position, which tells the client to open the visual snail's
     * version of the dialing screen (VisualDialingScreen).
     */
    private void openVisualDialing(ServerPlayer player) {
        NetworkHooks.openScreen(player, this, buf -> {
            buf.writeBoolean(false);              // not a handheld snail
            buf.writeItem(ItemStack.EMPTY);
            buf.writeBoolean(true);               // a visual snail: the client opens VisualDialingScreen
            buf.writeBlockPos(worldPosition);
        });
    }

    /** Registers this placed Visual Snail so it can be found as a call partner (server side, on load). */
    private void registerVisualSnail() {
        VisualSnailRegistry.register(this);

        // The saved blockstate may still show a call / sound model from before the world was saved
        // (never change blocks from inside onLoad - do it next tick)
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.getServer().execute(() -> {
                if (!isRemoved() && !isServerShuttingDown) {
                    updateBlockstateVisuals();
                }
            });
        }
    }

    /**
     * The projected screen can be up to PROJECTOR_MAX_THROW blocks from the snail (plus its own size and offsets), so the
     * renderer must not be culled just because the snail block itself is off screen.
     */
    @Override
    public AABB getRenderBoundingBox() {
        if (!isVisualSnail) {
            return super.getRenderBoundingBox();
        }
        double reach = VisualCallConstants.PROJECTOR_MAX_THROW + VisualSettings.maxScreenSize() + VisualCallConstants.SCREEN_OFFSET_MAX + 1.0;
        return new AABB(worldPosition).inflate(reach);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("gui.transpondersnails.dialing");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory pInventory, Player pPlayer) {
        if (!hasSnailNumber) {
            // Visual/Amplified Transponder Snails have no number and cannot be dialed
            return null;
        }

        // Ensure snail has a number when GUI opens
        if (!pPlayer.level().isClientSide) {
            ensureSnailNumberAssigned(pPlayer);
        }
        return new DialingMenu(containerId, pInventory, this);
    }

    // =================== CALLSESSION-BASED BLOCKSTATE MANAGEMENT ===================

    /**
     * Updates the visual blockstate based on CallSession state
     */
    private void updateBlockstateVisuals() {
        if (level == null || level.isClientSide()) {
            return; // Server side only
        }

        // Determine the correct model based on CallSession state
        String targetModel = determineModelFromCallSession();

        // Map model name to blockstate values
        boolean newHasSound = shouldHaveSoundState(targetModel);
        boolean newInCall = shouldHaveCallState(targetModel);

        // Get current blockstate values
        boolean currentHasSound = getCurrentVisualSoundState();
        boolean currentInCall = getCurrentVisualCallState();

        // Only update if changed or it's been a while since last update
        long now = System.currentTimeMillis();
        if (currentHasSound != newHasSound ||
                currentInCall != newInCall) {

            TransponderSnailBlock.updateVisualState(level, worldPosition, newHasSound, newInCall);
            lastBlockstateUpdate = now;

        }
    }

    /**
     * Determines which model should be used based on CallSession state
     */
    private String determineModelFromCallSession() {
        // Visual Transponder Snails are driven by VisualCallManager, not by a CallSession
        if (isVisualSnail) {
            return determineVisualModel();
        }

        // If no active call session, check for ambient sounds (like disconnect sound)
        if (currentCallSession == null) {
            if (hasAmbientSound) {
                return "transponder_snail_sound"; // Disconnect/end call sound
            }
            return "transponder_snail"; // Normal idle
        }

        // Use CallSession state to determine model
        switch (currentCallSession.getState()) {
            case INITIATING:
                // Calling snail - shows normal texture while setting up call
                return "transponder_snail";

            case RINGING:
                // Receiving snail - shows sound texture (ringing)
                if (isThisSnailBeingCalled()) {
                    return "transponder_snail_sound"; // Snail that is ringing
                } else {
                    return "transponder_snail"; // Snail that is calling
                }

            case CONNECTED:
                // In call - check for active sound transmission
                if (hasAmbientSound) {
                    return "transponder_snail_active"; // In call receiving sound
                } else {
                    return "transponder_snail_call"; // In call no sound
                }

            case ENDING:
                // Call ending - play disconnect sound
                return "transponder_snail_sound";

            case ENDED:
                // Call ended - brief disconnect sound then return to idle
                if (hasAmbientSound) {
                    return "transponder_snail_sound"; // On call ended/disconnected
                } else {
                    return "transponder_snail"; // Back to idle
                }

            default:
                return "transponder_snail"; // Fallback to idle
        }
    }

    /**
     * Check if this specific snail is the one being called (ringing)
     */
    private boolean isThisSnailBeingCalled() {
        if (currentCallSession == null || assignedSnailNumber == -1) {
            return false;
        }

        // Check if this snail is a participant and if it's in ringing state
        return currentCallSession.isParticipant(assignedSnailNumber) && isRinging;
    }

    /**
     * Maps model name to HAS_SOUND blockstate value
     */
    private boolean shouldHaveSoundState(String modelName) {
        switch (modelName) {
            case "transponder_snail":
                return false; // Idle, calling
            case "transponder_snail_sound":
                return true;  // Ringing, busy, disconnect
            case "transponder_snail_call":
                return false; // In call, no sound
            case "transponder_snail_active":
                return true;  // In call with sound
            default:
                return false;
        }
    }

    /**
     * Maps model name to IN_CALL blockstate value
     */
    private boolean shouldHaveCallState(String modelName) {
        switch (modelName) {
            case "transponder_snail":
                return false; // Idle, calling
            case "transponder_snail_sound":
                return false; // Ringing, busy, disconnect
            case "transponder_snail_call":
                return true;  // In call, no sound
            case "transponder_snail_active":
                return true;  // In call with sound
            default:
                return false;
        }
    }

    /**
     * Set the current call session for this snail
     */
    public void setCallSession(CallSession callSession) {
        this.currentCallSession = callSession;
        updateBlockstateVisuals();

    }

    /**
     * Clear the current call session
     */
    public void clearCallSession() {
        this.currentCallSession = null;
        updateBlockstateVisuals();
    }

    /**
     * Get the current call session
     */
    public CallSession getCallSession() {
        return currentCallSession;
    }

    /**
     * Check if block currently has the "sound" visual state
     */
    private boolean getCurrentVisualSoundState() {
        if (level != null) {
            BlockState state = level.getBlockState(worldPosition);
            if (state.getBlock() instanceof TransponderSnailBlock) {
                return state.getValue(TransponderSnailBlock.HAS_SOUND);
            }
        }
        return false;
    }

    /**
     * Check if block currently has the "call" visual state
     */
    public boolean getCurrentVisualCallState() {
        if (level != null) {
            BlockState state = level.getBlockState(worldPosition);
            if (state.getBlock() instanceof TransponderSnailBlock) {
                return state.getValue(TransponderSnailBlock.IN_CALL);
            }
        }
        return false;
    }

    // =================== BLOCKSTATE CALLBACK IMPLEMENTATION ===================

    @Override
    public void onSoundStateChanged(BlockPos pos, boolean hasAmbientSound) {
        if (pos.equals(worldPosition)) {
            this.hasAmbientSound = hasAmbientSound;
            updateBlockstateVisuals();

            // Log what type of sound event this is for debugging
            String soundType = "unknown";
            if (currentCallSession != null) {
                switch (currentCallSession.getState()) {
                    case RINGING:
                        soundType = hasAmbientSound ? "incoming ring" : "ring stopped";
                        break;
                    case CONNECTED:
                        soundType = hasAmbientSound ? "call audio" : "call audio stopped";
                        break;
                    case ENDING:
                    case ENDED:
                        soundType = hasAmbientSound ? "disconnect sound" : "disconnect sound ended";
                        break;
                }
            } else if (hasAmbientSound) {
                soundType = "ambient sound (no session)";
            }
        }
    }

    // =================== GLOBAL STATE MANAGEMENT ===================

    /**
     * Call this from your main mod class when server is shutting down
     */
    public static void setServerShuttingDown() {
        isServerShuttingDown = true;
        processedPositions.clear();
    }

    /**
     * Call this from your main mod class when server starts up
     */
    public static void setServerStartingUp() {
        isServerShuttingDown = false;
        processedPositions.clear();
    }

    // =================== CALL MANAGER HELPER METHODS ===================

    /**
     * Gets the call manager instance from the main mod class
     */
    private TransponderCallManager getCallManager() {
        return TransponderSnails.getCallManager();
    }

    /**
     * Safe method to check if call manager is available
     */
    private boolean isCallManagerAvailable() {
        return getCallManager() != null;
    }

    /**
     * Handle player interaction with the snail block
     * This should be called from TransponderSnailBlock.use() method
     *
     * @param player     The player interacting
     * @param isSneaking Whether the player is sneaking
     * @return The interaction result
     */
    public InteractionResult onPlayerInteraction(ServerPlayer player, boolean isSneaking) {
        if (isVisualSnail) {
            return handleVisualInteraction(player, isSneaking);
        }

        if (!hasSnailNumber) {
            // No Snail Number, no calling system - nothing to do here
            return InteractionResult.PASS;
        }

        if (!isCallManagerAvailable()) {
            player.displayClientMessage(
                    Component.literal("Voice chat system not available!")
                            .withStyle(net.minecraft.ChatFormatting.RED),
                    true
            );
            return InteractionResult.FAIL;
        }

        TransponderCallManager callManager = getCallManager();

        // Handle interactions based on current state and sneaking
        if (isRinging && activeCallId != null) {
            // Snail is ringing (incoming call)
            if (isSneaking) {
                // Sneak+Right Click while ringing: Open DialingMenu
                player.openMenu(this);
                return InteractionResult.SUCCESS;
            } else {
                // Right Click while ringing: Answer Call
                if (callManager.acceptCall(player, activeCallId)) {
                    setRinging(false);
                    setCallState(CallStateSyncPacket.CallState.CONNECTED);
                    player.displayClientMessage(
                            Component.literal("Call answered!")
                                    .withStyle(net.minecraft.ChatFormatting.GREEN),
                            true
                    );
                    return InteractionResult.SUCCESS;
                } else {
                    player.displayClientMessage(
                            Component.literal("Failed to answer call!")
                                    .withStyle(net.minecraft.ChatFormatting.RED),
                            true
                    );
                    return InteractionResult.FAIL;
                }
            }
        } else if (activeCallId != null && currentCallState == CallStateSyncPacket.CallState.CONNECTED) {
            // Snail is in an active call
            if (isSneaking) {
                // Sneak+Right Click in call: Open DialingMenu
                player.openMenu(this);
                return InteractionResult.SUCCESS;
            } else {
                // Right Click in call: End Call (only if player is in the call)
                if (callManager.isInCall(player.getUUID())) {
                    callManager.endCall(player);
                    player.displayClientMessage(
                            Component.literal("Call ended!")
                                    .withStyle(net.minecraft.ChatFormatting.YELLOW),
                            true
                    );
                    return InteractionResult.SUCCESS;
                } else {
                    // Player is not in the call - snail is busy
                    player.displayClientMessage(
                            Component.literal("Transponder Snail is busy!")
                                    .withStyle(net.minecraft.ChatFormatting.YELLOW),
                            true
                    );
                    return InteractionResult.FAIL;
                }
            }
        } else if (currentCallState == CallStateSyncPacket.CallState.IDLE) {
            // Snail is idle (not in call, not ringing)
            // Both Right Click and Sneak+Right Click: Open DialingMenu
            player.openMenu(this);
            return InteractionResult.SUCCESS;
        } else {
            // Snail is in some other state (dialing, busy, etc.)
            if (isSneaking) {
                // Sneak+Right Click: Still allow GUI access for monitoring
                player.openMenu(this);
                return InteractionResult.SUCCESS;
            } else {
                // Right Click: Snail is busy
                player.displayClientMessage(
                        Component.literal("Transponder Snail is busy!")
                                .withStyle(net.minecraft.ChatFormatting.YELLOW),
                        true
                );
                return InteractionResult.FAIL;
            }
        }
    }

    /**
     * Handle player interaction with the snail block
     */
    public InteractionResult onUse(ServerPlayer player) {
        return onPlayerInteraction(player, false);
    }

    /**
     * Reset audio readiness (called when call ends)
     */
    private void resetAudioReadiness() {
        this.audioReady = false;
    }

    // =================== ENHANCED CALL LIFECYCLE CALLBACKS ===================

    /**
     * Called by the call manager when this snail receives an incoming call
     */
    public void onIncomingCall(UUID callId, int callerSnailNumber, CallSession callSession) {
        this.activeCallId = callId;
        setRinging(true);
        setChanged();
        setCallState(CallStateSyncPacket.CallState.RINGING_IN);
        this.ringStartTime = System.currentTimeMillis();

        // Set the call session - this will trigger RINGING state
        setCallSession(callSession);

        // Notify nearby players
        List<ServerPlayer> nearbyPlayers = getNearbyListeners();
        for (ServerPlayer player : nearbyPlayers) {
            player.displayClientMessage(Component.literal("Transponder Snail is ringing!")
                    .withStyle(net.minecraft.ChatFormatting.YELLOW),true);

            // Start ringtone sound for nearby players
            TransponderCallManager callManager = getCallManager();
            if (callManager != null) {
                CallSoundManager soundManager = callManager.getSoundManager();
                if (soundManager != null) {
                    soundManager.playLocationalRingTone(player, worldPosition);
                }
            }
        }

        // Sync call state to clients
        CallStateSyncPacket packet = new CallStateSyncPacket(
                CallStateSyncPacket.CallState.RINGING_IN,
                callId,
                callerSnailNumber,
                "Incoming from #" + callerSnailNumber
        );

        // Send packet to nearby players with dialing menus open
        if (level instanceof ServerLevel) {
            for (ServerPlayer player : nearbyPlayers) {
                if (player.containerMenu instanceof DialingMenu dialingMenu &&
                        dialingMenu.getBlockEntity() == this) {
                    ModPackets.sendToPlayer(packet, player);
                }
            }
        }

    }

    /**
     * Called by the call manager when a call is connected
     */
    public void onCallConnected(UUID callId, CallSession callSession) {
        this.activeCallId = callId;
        setRinging(false);
        setChanged();
        setCallState(CallStateSyncPacket.CallState.CONNECTED);

        // Update the call session state - this will trigger CONNECTED state
        setCallSession(callSession);

        List<ServerPlayer> nearbyPlayers = getNearbyListeners();

        // Notify nearby players
        for (ServerPlayer player : nearbyPlayers) {
            player.displayClientMessage(
                    Component.literal("Call connected!")
                            .withStyle(net.minecraft.ChatFormatting.GREEN),
                    true
            );
        }

    }

    /**
     * Called when call is fully connected and audio channels are ready
     */
    public void onCallFullyConnected(UUID callId) {
        if (this.activeCallId != null && this.activeCallId.equals(callId)) {
            this.audioReady = true;
            setChanged();
        }
    }

    /**
     * Called by the call manager when a call ends
     */
    public void onCallEnded(UUID callId) {
        boolean wasRinging = isRinging;

        this.activeCallId = null;
        setRinging(false);
        clearDialedNumber();
        resetAudioReadiness(); // Add this line
        setChanged();
        setCallState(CallStateSyncPacket.CallState.IDLE);

        // Clear the call session - this will return to idle state
        clearCallSession();

        List<ServerPlayer> nearbyPlayers = getNearbyListeners();

        // Notify nearby players
        for (ServerPlayer player : nearbyPlayers) {
            if (wasRinging) {
                player.displayClientMessage(
                        Component.literal("Incoming call ended.")
                                .withStyle(net.minecraft.ChatFormatting.GRAY),
                        true
                );
            } else {
                player.displayClientMessage(
                        Component.literal("Call ended.")
                                .withStyle(net.minecraft.ChatFormatting.GRAY),
                        true
                );
            }
        }

    }

    /**
     * Called by the call manager when a call attempt fails
     */
    public void onCallFailed(String reason) {
        setCallState(CallStateSyncPacket.CallState.IDLE);
        clearCallSession();

        // Notify nearby players
        List<ServerPlayer> nearbyPlayers = getNearbyListeners();
        for (ServerPlayer player : nearbyPlayers) {
            player.displayClientMessage(
                    Component.literal("Call failed: " + reason)
                            .withStyle(net.minecraft.ChatFormatting.RED),
                    true
            );
        }

    }

    /**
     * Called by the call manager when target is busy
     */
    public void onTargetBusy(int targetNumber) {
        setCallState(CallStateSyncPacket.CallState.BUSY);
        updateBlockstateVisuals();

        List<ServerPlayer> nearbyPlayers = getNearbyListeners();

        // Notify nearby players
        for (ServerPlayer player : nearbyPlayers) {
            player.displayClientMessage(
                    Component.literal("Snail #" + targetNumber + " is busy!")
                            .withStyle(net.minecraft.ChatFormatting.YELLOW),
                    true
            );
        }

        // Reset to idle after a short delay
        if (level instanceof ServerLevel) {
            level.getServer().execute(() -> {
                try {
                    Thread.sleep(2000); // 2 second delay
                    setCallState(CallStateSyncPacket.CallState.IDLE);
                    clearCallSession();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
        }
    }

    /**
     * Check if this snail is ready to transmit/receive audio
     */
    public boolean isAudioReady() {
        return audioReady &&
                currentCallState == CallStateSyncPacket.CallState.CONNECTED &&
                getCurrentVisualCallState();
    }

    // =================== CALL STATE MANAGEMENT ===================

    /**
     * Sets the current call state and syncs to nearby players with open GUIs
     */
    private void setCallState(CallStateSyncPacket.CallState newState) {
        if (newState != currentCallState) {
            CallStateSyncPacket.CallState oldState = currentCallState;
            this.currentCallState = newState;
            setChanged();

            updateBlockstateVisuals();

            // Sync call state to nearby players with open dialing menus
            if (level instanceof ServerLevel) {
                List<ServerPlayer> nearbyPlayers = getNearbyListeners();
                for (ServerPlayer player : nearbyPlayers) {
                    if (player.containerMenu instanceof DialingMenu dialingMenu &&
                            dialingMenu.getBlockEntity() == this) {
                        ModPackets.sendToPlayer(new CallStateSyncPacket(newState, activeCallId, -1,
                                getStateMessage(newState)), player);
                    }
                }
            }

        }
    }

    /**
     * Gets a human-readable message for the current call state
     */
    private String getStateMessage(CallStateSyncPacket.CallState state) {
        switch (state) {
            case IDLE:
                return "";
            case DIALING:
                return "Dialing...";
            case RINGING_OUT:
                return "Calling...";
            case RINGING_IN:
                return "Incoming call";
            case CONNECTED:
                return "Connected";
            case BUSY:
                return "Busy";
            case DISCONNECTED:
                return "Disconnected";
            default:
                return "";
        }
    }

    public CallStateSyncPacket.CallState getCurrentCallState() {
        return currentCallState;
    }

    // =================== ENHANCED COLOR METHODS ===================

    /**
     * Transfer colors from a Den Den Mushi item to this block entity
     * Used during crafting or placement
     */
    public void transferColorsFromDenDenMushi(ItemStack denDenMushiItem) {
        if (denDenMushiItem.getItem() instanceof DenDenMushiItem && DenDenMushiItem.isCaptured(denDenMushiItem)) {
            this.bodyColor = DenDenMushiItem.getBodyColor(denDenMushiItem);
            this.shellColor = DenDenMushiItem.getShellColor(denDenMushiItem);
            this.colorsInitialized = true;
            setChanged();
        }
    }

    /**
     * Create a Den Den Mushi item with this block entity's colors
     * Used when breaking the block with colors preserved
     */
    public ItemStack createDenDenMushiWithColors() {
        ItemStack stack = new ItemStack(ModItems.DEN_DEN_MUSHI.get());

        if (colorsInitialized) {
            CompoundTag nbt = stack.getOrCreateTag();
            nbt.putInt("BodyColor", bodyColor);
            nbt.putInt("ShellColor", shellColor);
        }

        return stack;
    }

    public boolean isColorsInitialized() {
        return colorsInitialized;
    }

    /**
     * Check if this block entity can be dyed
     */
    public boolean canBeDyed() {
        return colorsInitialized || hasAssignedNumber();
    }

    /**
     * Apply dye to this block entity (enhanced version)
     */
    public boolean applyDye(Item dyeItem, @Nullable Player player) {
        if (dyeItem instanceof DyeItem dye) {
            // REMOVED: Don't call initializeSnailColors here - colors should already exist

            int newColor = dye.getDyeColor().getId();
            if (newColor != shellColor) {
                setShellColor(newColor);

                if (player instanceof ServerPlayer serverPlayer) {

                }

                return true;
            } else {
                if (player instanceof ServerPlayer serverPlayer) {

                }
            }
        }
        return false;
    }



    /**
     * Gets color data formatted for client-side rendering
     */
    public CompoundTag getColorData() {
        CompoundTag data = new CompoundTag();
        data.putInt("BodyColor", getBodyColor());
        data.putInt("ShellColor", shellColor);
        data.putBoolean("ColorsInitialized", colorsInitialized);
        return data;
    }

    /**
     * Enhanced version that includes colors in render data
     */
    public CompoundTag getBlockEntityRenderData() {
        CompoundTag data = new CompoundTag();
        data.putInt("BodyColor", getBodyColor());
        data.putInt("ShellColor", shellColor);
        data.putBoolean("ColorsInitialized", colorsInitialized);
        return data;
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag); // This saves ALL data including colors
        return tag;
    }

    @Override
    public void handleUpdateTag(CompoundTag tag) {
        load(tag); // This loads ALL data including colors
    }

    // 3. Test method - Add this temporarily to debug
    public void testColorSystem() {
    }

    // =================== LIFECYCLE METHODS ===================

    /**
     * Called when the block entity is loaded (chunk load, server start, etc.)
     */
    @Override
    public void onLoad() {
        super.onLoad();

        if (level != null && level.isClientSide && !colorsInitialized) {
            // Request sync from server on client load
            setChanged();
        }

        if (level.isClientSide && isVisualSnail && VisualRoles.ofEntity(this) == VisualSnailRole.CAMERA) {
            VisualCameraPositions.add(worldPosition); // so the renderer can light the eyes of a camera that is live (see VisualCameraPositions)
        }

        if (!level.isClientSide && !isUnloading) {

            // Calls only exist in memory - never resurrect call state that was saved to disk
            resetPersistedCallState();

            if (isVisualSnail) {
                registerVisualSnail();
            }

            // Prevent processing the same position multiple times
            if (processedPositions.contains(worldPosition)) {
                return;
            }

            processedPositions.add(worldPosition);
            hasBeenLoaded = true;

            // Register for sound state updates with the sound manager
            if (isCallManagerAvailable()) {
                CallSoundManager soundManager = getCallManager().getSoundManager();
                if (soundManager != null) {
                    soundManager.registerBlockstateCallback(this);
                }
            }

            // Handle deferred validation
            if (needsValidation && !validationCompleted) {
                // Schedule validation on next server tick (only once)
                if (level instanceof ServerLevel serverLevel) {
                    serverLevel.getServer().execute(() -> {
                        if (!isUnloading && !isServerShuttingDown && needsValidation && !validationCompleted) {
                            performDeferredValidation();
                        }
                    });
                }
            } else if (hasAssignedNumber() && !isUnloading) {
                // Re-register with call manager if we have valid data
                registerWithCallManager();
            }
        }
    }

    /**
     * Calls only live in memory inside TransponderCallManager, but this block entity saves its call
     * state to disk (saveAdditional) and restores it on load. A snail that was saved while in a call -
     * server stop, chunk unload, or saved after a call ended without the snail being told - would come
     * back "connected" or "ringing" with no call behind it and stay that way forever. (Right-click just
     * reports "busy" / "Failed to answer call!".)
     *
     * Runs on the server when the block entity loads. saveAdditional/load are left untouched because
     * getUpdateTag() reuses them to sync this state to clients.
     */
    private void resetPersistedCallState() {
        boolean stale = activeCallId != null
                || isRinging
                || currentCallState != CallStateSyncPacket.CallState.IDLE
                || hasAmbientSound
                || inActiveCall
                || audioReady;
        if (!stale) {
            return;
        }

        this.activeCallId = null;
        this.isRinging = false;
        this.ringStartTime = 0;
        this.currentCallState = CallStateSyncPacket.CallState.IDLE;
        this.hasAmbientSound = false;
        this.inActiveCall = false;
        this.audioReady = false;
        this.currentCallSession = null;
        setChanged();

        // The saved blockstate may still show the "call"/"sound" model - refresh it next tick
        // (never change blocks from inside onLoad)
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.getServer().execute(() -> {
                if (!isRemoved() && !isServerShuttingDown) {
                    updateBlockstateVisuals();
                }
            });
        }
    }

    /**
     * Called when the block entity is unloaded or removed
     */
    @Override
    public void setRemoved() {
        if (isUnloading) {
            return;
        }

        isUnloading = true;
        processedPositions.remove(worldPosition);
        if (level.isClientSide) {
            VisualCameraPositions.remove(worldPosition);
        }

        if (!level.isClientSide) {

            if (isVisualSnail) {
                // Leave the pairing pool and end any video call this snail is part of
                VisualSnailRegistry.unregister(this);
                VisualCallManager visualCalls = VisualCallManager.peek();
                if (visualCalls != null) {
                    visualCalls.onSnailRemoved(this);
                }
            }

            // Unregister from call manager
            unregisterFromCallManager();

            // Unregister sound callback
            if (isCallManagerAvailable()) {
                CallSoundManager soundManager = getCallManager().getSoundManager();
                if (soundManager != null) {
                    soundManager.unregisterBlockstateCallback(this);
                }
            }

            // End any active calls
            if (!isVisualSnail && activeCallId != null && isCallManagerAvailable()) {
                TransponderCallManager callManager = getCallManager();
                callManager.endCallBySnailNumber(assignedSnailNumber);
            }

            // Reset blockstate to idle
            if (!isServerShuttingDown && level != null && level.getBlockState(worldPosition).getBlock() instanceof TransponderSnailBlock) {
                TransponderSnailBlock.updateVisualState(level, worldPosition, false, false);
            }
        }

        super.setRemoved();
    }

    // =================== ENHANCED SNAIL NUMBERING SYSTEM ===================

    /**
     * Enhanced deferred validation that prevents infinite loops
     */
    private void performDeferredValidation() {
        if (!hasSnailNumber || !needsValidation || level.isClientSide || isUnloading || isServerShuttingDown || validationCompleted) {
            return;
        }

        validationCompleted = true;


        SnailNumberRegistry registry = SnailNumberRegistry.getInstance();
        if (registry == null) {
            System.err.println("TransponderSnailBlockEntity: Registry not available - skipping validation");
            needsValidation = false;
            return;
        }

        // An admin removed this snail's number while its chunk was unloaded. Do NOT restore it below
        // (that would silently hand it a fresh random number) - wipe it so it registers on next use.
        if (snailUUID != null && registry.isRevoked(snailUUID)) {
            System.out.println("TransponderSnailBlockEntity: Snail " + snailUUID + " at " + worldPosition +
                    " was removed by an admin - resetting it");
            revokeSnailIdentity();
            return;
        }

        boolean restored = false;

        // If we have both UUID and number, validate they match in registry
        if (snailUUID != null && assignedSnailNumber != -1 && initialized) {
            UUID registryUUID = registry.getSnailByNumber(assignedSnailNumber);
            if (registryUUID != null && registryUUID.equals(snailUUID)) {
                // Data is valid - and the number is recorded as the right kind (heals a number recorded with the wrong one)
                registry.setKind(snailUUID, snailKind());
                restored = true;
            } else {
                // Data mismatch - try to restore
                int restoredNumber = registry.assignNumberToSnail(snailUUID, snailKind());
                if (restoredNumber != -1) {
                    this.assignedSnailNumber = restoredNumber;
                    this.initialized = true;
                    setChanged();
                    restored = true;
                }
            }
        }
        // If we have UUID but no number, try to restore
        else if (snailUUID != null && (assignedSnailNumber == -1 || !initialized)) {
            int registryNumber = registry.getSnailNumber(snailUUID);
            if (registryNumber != -1) {
                // UUID exists in registry
                this.assignedSnailNumber = registryNumber;
                this.initialized = true;
                setChanged();
                restored = true;
            } else {
                // UUID not in registry - try to assign new number
                int restoredNumber = registry.assignNumberToSnail(snailUUID, snailKind());
                if (restoredNumber != -1) {
                    this.assignedSnailNumber = restoredNumber;
                    this.initialized = true;
                    setChanged();
                    restored = true;
                }
            }
        }

        if (restored && !isUnloading && !isServerShuttingDown) {
            // Register with call manager now that we have valid data
            registerWithCallManager();
        } else if (!restored) {
            System.err.println("TransponderSnailBlockEntity: Deferred validation failed - snail will need manual reassignment");
            // Reset to uninitialized state
            this.initialized = false;
            this.assignedSnailNumber = -1;
            setChanged();
        }

        needsValidation = false;
    }

    /**
     * Ensures this placed snail has a number assigned.
     */
    public void ensureSnailNumberAssigned(Player player) {
        if (!hasSnailNumber) {
            return;
        }

        // If we need validation, do it now
        if (needsValidation) {
            performDeferredValidation();
        }

        // A snail whose number was removed by an admin must start over with a brand new identity
        SnailNumberRegistry revocationCheck = SnailNumberRegistry.getInstance();
        if (revocationCheck != null && snailUUID != null && revocationCheck.isRevoked(snailUUID)) {
            revokeSnailIdentity();
        }

        // Check if our current number is still valid in the registry
        if (initialized && snailUUID != null && assignedSnailNumber != -1) {
            SnailNumberRegistry registry = SnailNumberRegistry.getInstance();
            if (registry != null) {
                UUID registryUUID = registry.getSnailByNumber(assignedSnailNumber);
                if (registryUUID != null && registryUUID.equals(snailUUID)) {
                    registry.setKind(snailUUID, snailKind());
                    // Number is still valid - just sync to client
                    if (player instanceof ServerPlayer serverPlayer) {
                        ModPackets.sendToPlayer(new SnailNumberSyncPacket(assignedSnailNumber), serverPlayer);
                    }
                    return;
                } else {
                    // Number is no longer valid - attempt restoration
                    int restoredNumber = registry.assignNumberToSnail(snailUUID, snailKind());
                    if (restoredNumber != -1) {
                        this.assignedSnailNumber = restoredNumber;
                        setChanged();
                        registerWithCallManager();

                        if (player instanceof ServerPlayer serverPlayer) {
                            ModPackets.sendToPlayer(new SnailNumberSyncPacket(restoredNumber), serverPlayer);
                            Component message = Component.literal("Your " + snailKind().displayName() + " number has been restored to #" + restoredNumber)
                                    .withStyle(net.minecraft.ChatFormatting.GREEN);
                            serverPlayer.sendSystemMessage(message);
                        }
                        return;
                    } else {
                        // Restoration failed - reset and continue to new assignment
                        System.err.println("TransponderSnailBlockEntity: Failed to restore number - will assign new one");
                        this.initialized = false;
                        this.assignedSnailNumber = -1;
                    }
                }
            }
        }

        try {
            // Generate new UUID if needed
            if (snailUUID == null) {
                snailUUID = UUID.randomUUID();
            }

            SnailNumberRegistry registry = SnailNumberRegistry.getInstance();
            if (registry != null) {
                int newNumber = registry.assignNumberToSnail(snailUUID, snailKind());
                if (newNumber != -1) {
                    this.assignedSnailNumber = newNumber;
                    this.initialized = true;
                    if (!isVisualSnail) {
                        initializeSnailColors(); // a visual snail keeps the colors it already has
                    }
                    setChanged();

                    // Update blockstate with initial shell color
                    if (level != null && !level.isClientSide) {
                        BlockState currentState = level.getBlockState(worldPosition);
                        level.sendBlockUpdated(worldPosition, currentState, currentState, Block.UPDATE_ALL);
                    }

                    // Register with call manager
                    registerWithCallManager();

                    // Send congratulations message
                    if (player instanceof ServerPlayer serverPlayer) {
                        Component message = Component.literal("Your " + snailKind().displayName() + " has been assigned number #" + assignedSnailNumber)
                                .withStyle(net.minecraft.ChatFormatting.GREEN);
                        serverPlayer.sendSystemMessage(message);

                        // Send sync packet to client
                        ModPackets.sendToPlayer(new SnailNumberSyncPacket(assignedSnailNumber), serverPlayer);
                    }

                } else {
                    System.err.println("TransponderSnailBlockEntity: Failed to assign number - registry may be full");
                }
            } else {
                System.err.println("TransponderSnailBlockEntity: Registry not available for number assignment");
            }
        } catch (Exception e) {
            System.err.println("TransponderSnailBlockEntity: Error assigning snail number: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Register this snail block with the call manager for location tracking
     */
    private void registerWithCallManager() {
        // Visual snails are not part of the phone call manager: a phone must never be able to ring one
        if (isVisualSnail || !isCallManagerAvailable() || !hasAssignedNumber() || isUnloading) {
            return;
        }

        TransponderCallManager callManager = getCallManager();
        if (!callManager.isSnailBlockRegistered(assignedSnailNumber)) {
            callManager.registerSnailBlock(assignedSnailNumber, this);
        }
    }

    /**
     * Unregister this snail block from the call manager
     */
    public void unregisterFromCallManager() {
        if (isVisualSnail || !isCallManagerAvailable() || !hasAssignedNumber()) {
            return;
        }

        TransponderCallManager callManager = getCallManager();
        if (callManager.isSnailBlockRegistered(assignedSnailNumber)) {
            callManager.unregisterSnailBlock(assignedSnailNumber);
        }
    }

    /**
     * Gets the snail number for this block entity
     */
    public int getSnailNumber() {
        return assignedSnailNumber;
    }

    /**
     * Gets the snail UUID for this block entity
     */
    public UUID getSnailUUID() {
        return snailUUID;
    }

    /**
     * Check if this snail has been assigned a number
     */
    public boolean hasAssignedNumber() {
        return initialized && assignedSnailNumber != -1 && snailUUID != null;
    }

    /**
     * Wipes this placed snail's identity after an admin removed its number (/snailnumber remove).
     * The snail leaves the call manager (ending any call it is in) and forgets its UUID and number, so the
     * next player to right-click it registers a brand new one. Colors are kept.
     * Must be called on the server thread.
     */
    public void revokeSnailIdentity() {
        // First: this needs the current number, and it ends any call the snail is part of.
        // Only if the call manager really holds THIS block under that number: after a removal the number
        // can be handed to a different snail, and that snail must not be unregistered by mistake.
        if (isCallManagerAvailable() && assignedSnailNumber != -1) {
            TransponderCallManager callManager = getCallManager();
            if (callManager.getRegisteredSnailBlock(assignedSnailNumber) == this) {
                callManager.unregisterSnailBlock(assignedSnailNumber);
            }
        }

        this.snailUUID = null;
        this.assignedSnailNumber = -1;
        this.initialized = false;
        this.needsValidation = false;
        setChanged();

        // Tell nearby clients (the number is part of the update tag)
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
        }
    }

    // =================== ITEM STACK METHODS ===================

    /**
     * Returns an ItemStack representation with proper NBT for the handler system
     */
    public ItemStack getSnailItemStack() {
        ItemStack stack = new ItemStack(this.getBlockState().getBlock().asItem());

        if (hasAssignedNumber()) {
            CompoundTag nbt = stack.getOrCreateTag();
            nbt.putUUID("snail_uuid", snailUUID);
            nbt.putInt("cached_snail_number", assignedSnailNumber);
            nbt.putLong("activation_time", System.currentTimeMillis());
            nbt.putString("snail_type", "BLOCK");
        }

        return stack;
    }

    /**
     * When the block is broken, preserves the snail data in the dropped item
     */
    @Override
    public void saveToItem(ItemStack stack) {
        // Call existing saveToItem logic
        unregisterFromCallManager();

        if (!isVisualSnail && activeCallId != null && isCallManagerAvailable()) {
            TransponderCallManager callManager = getCallManager();
            callManager.endCallBySnailNumber(assignedSnailNumber);
        }

        CompoundTag nbt = stack.getOrCreateTag();
        CompoundTag blockEntityTag = nbt.contains("BlockEntityTag")
                ? nbt.getCompound("BlockEntityTag")
                : new CompoundTag();
        boolean writeBlockEntityTag = false;

        if (hasAssignedNumber()) {
            nbt.putUUID("snail_uuid", snailUUID);
            nbt.putInt("cached_snail_number", assignedSnailNumber);
            nbt.putLong("activation_time", System.currentTimeMillis());
            nbt.putString("snail_type", "BLOCK");

            blockEntityTag.putUUID("SnailUUID", snailUUID);
            blockEntityTag.putInt("AssignedNumber", assignedSnailNumber);
            blockEntityTag.putBoolean("Initialized", initialized);
            writeBlockEntityTag = true;
        }

        // Colors are preserved independently of the Snail Number system, so the Visual and
        // Amplified Transponder Snail (which never have a number) still keep their colors when
        // broken and picked back up.
        if (colorsInitialized) {
            // Declare shellColorToSave outside the if block
            int shellColorToSave = shellColor;

            // Get shell color from blockstate (authoritative source for rendering)
            if (level != null) {
                BlockState state = level.getBlockState(worldPosition);
                if (state.getBlock() instanceof TransponderSnailBlock) {
                    shellColorToSave = state.getValue(TransponderSnailBlock.SHELL_COLOR);
                }
            }

            nbt.putInt("body_color", bodyColor);
            nbt.putInt("shell_color", shellColorToSave);

            blockEntityTag.putInt("BodyColor", bodyColor);
            blockEntityTag.putInt("ShellColor", shellColorToSave);
            blockEntityTag.putBoolean("ColorsInitialized", colorsInitialized);
            writeBlockEntityTag = true;
        }

        if (writeBlockEntityTag) {
            nbt.put("BlockEntityTag", blockEntityTag);
        }
    }

    /**
     * When the block is placed, restores data from the item if available
     */
    public void loadFromItem(ItemStack stack) {
        if (stack.hasTag()) {
            CompoundTag nbt = stack.getTag();

            // Visual/Amplified Transponder Snails never restore a Snail Number identity, even if
            // an item happens to carry legacy identity NBT (e.g. dropped before this block type
            // stopped using the numbering system).
            if (hasSnailNumber) {
                if (nbt.contains("BlockEntityTag")) {
                    CompoundTag blockEntityTag = nbt.getCompound("BlockEntityTag");
                    if (blockEntityTag.hasUUID("SnailUUID")) {
                        this.snailUUID = blockEntityTag.getUUID("SnailUUID");
                        this.assignedSnailNumber = blockEntityTag.getInt("AssignedNumber");
                        this.initialized = blockEntityTag.getBoolean("Initialized");
                        this.needsValidation = true; // CHANGE THIS TO FALSE
                        setChanged();
                    }
                }

                if (nbt.hasUUID("snail_uuid")) {
                    this.snailUUID = nbt.getUUID("snail_uuid");
                    this.assignedSnailNumber = nbt.getInt("cached_snail_number");
                    this.initialized = true;
                    this.needsValidation = true; // CHANGE THIS TO FALSE
                    setChanged();
                }
            }

            if (nbt.contains("body_color")) {
                this.bodyColor = nbt.getInt("body_color");
                this.shellColor = nbt.getInt("shell_color");
                this.colorsInitialized = true;
            }
        }
    }

    // =================== DIALING METHODS ===================

    public void dialDigit(int digit) {
        if (dialedNumber.length() < 4) {
            dialedNumber += digit;
            setChanged();
        }
    }

    public void clearDialedNumber() {
        dialedNumber = "";
        setChanged();
    }

    public String getDialedNumber() {
        return dialedNumber;
    }

    public void setDialedNumber(String number) {
        this.dialedNumber = number;
        setChanged();
    }

    @Nullable
    public ServerPlayer findNearbyPlayer() {
        if (!(level instanceof ServerLevel serverLevel)) {
            return null;
        }

        BlockPos pos = getBlockPos();
        ServerPlayer closestPlayer = null;
        double closestDistance = Double.MAX_VALUE;

        for (ServerPlayer player : serverLevel.players()) {
            double distance = player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (distance <= VoiceChatConstants.getSnailInteractionRange() * VoiceChatConstants.getSnailInteractionRange()) {
                if (distance < closestDistance) {
                    closestDistance = distance;
                    closestPlayer = player;
                }
            }
        }

        return closestPlayer;
    }

    public List<ServerPlayer> getNearbyListeners() {
        if (isCallManagerAvailable() && level instanceof ServerLevel serverLevel) {
            return getCallManager().getPlayersNearSnail(serverLevel, worldPosition, VoiceChatConstants.getSnailInteractionRange());
        }
        return List.of();
    }

    public void setRinging(boolean ringing) {
        if (this.isRinging != ringing) {
            this.isRinging = ringing;
            if (ringing) {
                this.ringStartTime = System.currentTimeMillis();
            } else {
                this.ringStartTime = 0;
            }
            setChanged();
            updateBlockstateVisuals();
        }
    }

    public void setActiveCall(UUID callId) {
        this.activeCallId = callId;
        setChanged();
        updateBlockstateVisuals();
    }

    public UUID getActiveCallId() {
        return activeCallId;
    }

    public boolean isRinging() {
        return isRinging;
    }

    public long getRingStartTime() {
        return ringStartTime;
    }

    // =================== COLOR CUSTOMIZATION METHODS ===================

    /**
     * Sets the shell color (when dyed)
     * @param dyeColor The dye color to apply (0-15)
     */
    public void setShellColor(int dyeColor) {
        if (dyeColor >= 0 && dyeColor <= 15 && dyeColor != this.shellColor) {
            this.shellColor = dyeColor;
            setChanged();

            DyeColor.byId(dyeColor).getName();
        }
    }

    /**
     * Initializes random pastel colors for this snail
     * Called when the snail is first assigned a number
     */
    private void initializeSnailColors() {
        if (colorsInitialized) {
            return;
        }

        this.bodyColor = generateRandomPastelColor();
        this.shellColor = 0;
        this.colorsInitialized = true;
        setChanged(); // This marks the block entity as needing sync
    }

    /**
     * Generates a random pastel color
     * Uses HSL color space for better pastel generation
     */
    private int generateRandomPastelColor() {
        Random random = new Random();

        // Generate random hue (0-360 degrees)
        float hue = random.nextFloat();

        // Pastel colors have moderate saturation (30-60%)
        float saturation = 0.3f + (random.nextFloat() * 0.3f);

        // Pastel colors have high lightness (70-90%)
        float lightness = 0.7f + (random.nextFloat() * 0.2f);

        // Convert HSL to RGB
        return hslToRgb(hue, saturation, lightness);
    }

    /**
     * Converts HSL color values to RGB integer
     */
    private int hslToRgb(float h, float s, float l) {
        float r, g, b;

        if (s == 0) {
            r = g = b = l; // Achromatic
        } else {
            float q = l < 0.5f ? l * (1 + s) : l + s - l * s;
            float p = 2 * l - q;
            r = hueToRgb(p, q, h + 1f/3f);
            g = hueToRgb(p, q, h);
            b = hueToRgb(p, q, h - 1f/3f);
        }

        int red = Math.round(r * 255);
        int green = Math.round(g * 255);
        int blue = Math.round(b * 255);

        return (red << 16) | (green << 8) | blue;
    }

    private float hueToRgb(float p, float q, float t) {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1f/6f) return p + (q - p) * 6 * t;
        if (t < 1f/2f) return q;
        if (t < 2f/3f) return p + (q - p) * (2f/3f - t) * 6;
        return p;
    }

    /**
     * Gets the body color for this snail
     */
    public int getBodyColor() {
        // DON'T initialize colors here - just return what we have
        if (!colorsInitialized) {
            return 0xFFFFFF;
        }
        return bodyColor;
    }

    /**
     * Gets the shell color (dye index) for this snail
     */
    public int getShellColor() {
        // Try to read from blockstate first (authoritative for rendering)
        if (level != null) {
            BlockState state = level.getBlockState(worldPosition);
            if (state.getBlock() instanceof TransponderSnailBlock) {
                return state.getValue(TransponderSnailBlock.SHELL_COLOR);
            }
        }
        // Fallback to stored value
        return shellColor;
    }

    public void ensureColorsInitialized() {
        if (!colorsInitialized) {
            initializeSnailColors();

            // Force sync to client immediately
            if (level != null && !level.isClientSide) {
                BlockState state = level.getBlockState(worldPosition);
                level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
            }
        }
    }

    // =================== NBT SERIALIZATION ===================

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);


        if (snailUUID != null) {
            tag.putUUID("SnailUUID", snailUUID);
        }
        tag.putInt("AssignedNumber", assignedSnailNumber);
        tag.putBoolean("Initialized", initialized);

        if (activeCallId != null) {
            tag.putUUID("ActiveCallId", activeCallId);
        }
        tag.putBoolean("IsRinging", isRinging);
        tag.putString("DialedNumber", dialedNumber);
        tag.putString("CallState", currentCallState.name());
        tag.putLong("RingStartTime", ringStartTime);

        tag.putBoolean("HasAmbientSound", hasAmbientSound);
        tag.putBoolean("InActiveCall", inActiveCall);
        tag.putBoolean("AudioReady", audioReady); // Add this line

        tag.putInt("BodyColor", bodyColor);
        tag.putInt("ShellColor", shellColor);
        tag.putBoolean("ColorsInitialized", colorsInitialized);
        tag.putInt("VisualScreenSize", screenSize);
        tag.putFloat("VisualScreenOffsetSide", screenOffsetSide);
        tag.putFloat("VisualScreenOffsetUp", screenOffsetUp);
        tag.putFloat("VisualScreenOffsetBack", screenOffsetBack);

        if (isVisualSnail) { // streams: the camera's identity and name, the owner, the projector's presets (the loot table copies these to the item)
            if (streamId != null) tag.putUUID("StreamId", streamId);
            tag.putString("StreamName", streamName);
            if (ownerId != null) tag.putUUID("StreamOwner", ownerId);
            tag.putString("StreamOwnerName", ownerName);
            ListTag list = new ListTag();
            for (int slot = 0; slot < StreamPresets.SLOTS; slot++) {
                StreamPresets.Preset preset = presets.get(slot);
                if (preset == null) continue;
                CompoundTag entry = new CompoundTag();
                entry.putInt("Slot", slot);
                entry.putUUID("Id", preset.id());
                entry.putString("Name", preset.name());
                list.add(entry);
            }
            tag.put("StreamPresets", list);
        }
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public void onDataPacket(net.minecraft.network.Connection net, ClientboundBlockEntityDataPacket pkt) {
        CompoundTag tag = pkt.getTag();
        if (tag != null) {
            load(tag);
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);

        if (tag.contains("BodyColor")) {
            this.bodyColor = tag.getInt("BodyColor");
            this.shellColor = tag.getInt("ShellColor");
            this.colorsInitialized = tag.getBoolean("ColorsInitialized");

            // CRITICAL: Force chunk re-render on client after loading colors
            if (level != null && level.isClientSide && colorsInitialized) {
                level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), Block.UPDATE_ALL);
            }
        }

        if (tag.hasUUID("SnailUUID")) {
            this.snailUUID = tag.getUUID("SnailUUID");
        }

        this.assignedSnailNumber = tag.getInt("AssignedNumber");
        this.initialized = tag.getBoolean("Initialized");

        if (!hasSnailNumber) {
            // Visual/Amplified Transponder Snails never keep a Snail Number, even if legacy save
            // data has one (e.g. saved before this block type stopped using the system).
            this.snailUUID = null;
            this.assignedSnailNumber = -1;
            this.initialized = false;
            this.needsValidation = false;
        } else if (!isServerShuttingDown && !validationCompleted && snailUUID != null && (assignedSnailNumber != -1 || initialized)) {
            this.needsValidation = true;
        }

        if (tag.hasUUID("ActiveCallId")) {
            this.activeCallId = tag.getUUID("ActiveCallId");
        }
        this.isRinging = tag.getBoolean("IsRinging");
        this.dialedNumber = tag.getString("DialedNumber");
        this.ringStartTime = tag.getLong("RingStartTime");

        try {
            String stateStr = tag.getString("CallState");
            if (!stateStr.isEmpty()) {
                this.currentCallState = CallStateSyncPacket.CallState.valueOf(stateStr);
            }
        } catch (IllegalArgumentException e) {
            this.currentCallState = CallStateSyncPacket.CallState.IDLE;
        }

        this.hasAmbientSound = tag.getBoolean("HasAmbientSound");
        this.inActiveCall = tag.getBoolean("InActiveCall");
        this.audioReady = tag.getBoolean("AudioReady"); // Add this line

        if (isVisualSnail) {
            this.streamId = tag.hasUUID("StreamId") ? tag.getUUID("StreamId") : null;
            this.streamName = VisualStreamNames.sanitize(tag.getString("StreamName"));
            this.ownerId = tag.hasUUID("StreamOwner") ? tag.getUUID("StreamOwner") : null;
            this.ownerName = VisualStreamNames.sanitize(tag.getString("StreamOwnerName"));
            this.presets.clearAll();
            if (tag.contains("StreamPresets", Tag.TAG_LIST)) {
                ListTag list = tag.getList("StreamPresets", Tag.TAG_COMPOUND);
                for (int i = 0; i < list.size(); i++) {
                    CompoundTag entry = list.getCompound(i);
                    if (entry.hasUUID("Id")) this.presets.set(entry.getInt("Slot"), entry.getUUID("Id"), entry.getString("Name"));
                }
            }
        }

        if (tag.contains("VisualScreenSize")) {
            this.screenSize = VisualScreenConfig.clampSize(tag.getInt("VisualScreenSize"), VisualSettings.maxScreenSize());
        }
        // clamped / snapped on load too, so a hand-edited or corrupted save cannot push the screen further than the limit
        this.screenOffsetSide = tag.contains("VisualScreenOffsetSide") ? VisualScreenConfig.snapOffset(tag.getFloat("VisualScreenOffsetSide")) : 0.0F;
        this.screenOffsetUp = tag.contains("VisualScreenOffsetUp") ? VisualScreenConfig.snapOffset(tag.getFloat("VisualScreenOffsetUp")) : 0.0F;
        if (tag.contains("VisualScreenOffsetBack")) {
            this.screenOffsetBack = VisualScreenConfig.snapBack(tag.getFloat("VisualScreenOffsetBack"));
        } else if (tag.contains("VisualScreenOffsetFront")) {
            // saved with the earlier menu: "front" was signed (+ = towards the snail, - = further back). Only "back" is allowed now.
            this.screenOffsetBack = VisualScreenConfig.snapBack(-tag.getFloat("VisualScreenOffsetFront"));
        } else {
            this.screenOffsetBack = 0.0F;
        }
    }
}