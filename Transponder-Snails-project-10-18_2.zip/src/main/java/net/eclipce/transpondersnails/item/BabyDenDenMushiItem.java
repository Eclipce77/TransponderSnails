package net.eclipce.transpondersnails.item;

import net.eclipce.transpondersnails.entity.ModEntities;
import net.eclipce.transpondersnails.entity.custom.DenDenMushiEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.List;
import java.util.function.Consumer;

public class BabyDenDenMushiItem extends Item {

    // NBT tag keys (same as adult)
    private static final String BODY_COLOR_TAG = "BodyColor";
    private static final String SHELL_COLOR_TAG = "ShellColor";
    private static final String ENTITY_DATA_TAG = "EntityData";

    public BabyDenDenMushiItem(Properties properties) {
        super(properties);
    }

    /**
     * CRITICAL: This method tells Minecraft to use the custom 3D renderer for this item.
     * Without this, the baby will render as a flat 2D sprite and have no body tint!
     */
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                return new DenDenMushiItemRenderer(
                        Minecraft.getInstance().getBlockEntityRenderDispatcher(),
                        Minecraft.getInstance().getEntityModels()
                );
            }
        });
    }

    /**
     * Creates a baby Den Den Mushi item with specific colors
     */
    public static ItemStack createWithColors(int bodyColor, int shellColor) {
        ItemStack stack = new ItemStack(ModItems.BABY_DEN_DEN_MUSHI.get());
        CompoundTag nbt = stack.getOrCreateTag();
        nbt.putInt(BODY_COLOR_TAG, bodyColor);
        nbt.putInt(SHELL_COLOR_TAG, shellColor);
        return stack;
    }

    /**
     * Store entity data in item when picking up a baby
     */
    public static ItemStack createFromEntity(DenDenMushiEntity entity) {
        ItemStack stack = new ItemStack(ModItems.BABY_DEN_DEN_MUSHI.get());
        CompoundTag nbt = stack.getOrCreateTag();

        // Get colors from entity
        int entityShellColor = entity.getShellColor();
        int entityBodyColor = entity.getBodyColor();

        // Store colors in NBT
        nbt.putInt(BODY_COLOR_TAG, entityBodyColor);
        nbt.putInt(SHELL_COLOR_TAG, entityShellColor);

        // Store entity data
        CompoundTag entityData = new CompoundTag();
        entity.addAdditionalSaveData(entityData);
        nbt.put(ENTITY_DATA_TAG, entityData);

        return stack;
    }

    /**
     * Apply item data to entity when placed
     */
    public static void applyToEntity(ItemStack stack, DenDenMushiEntity entity) {
        CompoundTag nbt = stack.getTag();
        if (nbt == null) return;

        // Apply colors
        if (nbt.contains(BODY_COLOR_TAG)) {
            entity.setBodyColor(nbt.getInt(BODY_COLOR_TAG));
        }
        if (nbt.contains(SHELL_COLOR_TAG)) {
            entity.setShellColor(nbt.getInt(SHELL_COLOR_TAG));
        }

        // Ensure entity is baby
        entity.setBaby(true);

        // Apply other entity data
        if (nbt.contains(ENTITY_DATA_TAG)) {
            CompoundTag entityData = nbt.getCompound(ENTITY_DATA_TAG);
            entity.readAdditionalSaveData(entityData);
        }
    }

    /**
     * Get body color for rendering and tooltips
     */
    public static int getBodyColor(ItemStack stack) {
        CompoundTag nbt = stack.getTag();
        if (nbt != null && nbt.contains(BODY_COLOR_TAG)) {
            return nbt.getInt(BODY_COLOR_TAG);
        }
        return 0xF5E6A3; // Default pastel yellow
    }

    /**
     * Get shell color for rendering and tooltips
     */
    public static int getShellColor(ItemStack stack) {
        CompoundTag nbt = stack.getTag();
        if (nbt != null && nbt.contains(SHELL_COLOR_TAG)) {
            return nbt.getInt(SHELL_COLOR_TAG);
        }
        return 0; // Default white
    }

    /**
     * Sets the body and shell colors for a baby Den Den Mushi item
     */
    public static void setColors(ItemStack stack, int bodyColor, int shellColor) {
        if (stack.isEmpty() || !(stack.getItem() instanceof BabyDenDenMushiItem)) {
            return;
        }

        CompoundTag nbt = stack.getOrCreateTag();
        nbt.putInt(BODY_COLOR_TAG, bodyColor);
        nbt.putInt(SHELL_COLOR_TAG, shellColor);
    }

    /**
     * Marks the baby Den Den Mushi as captured (has colors)
     */
    public static void setCaptured(ItemStack stack, boolean captured) {
        if (stack.isEmpty() || !(stack.getItem() instanceof BabyDenDenMushiItem)) {
            return;
        }

        CompoundTag nbt = stack.getOrCreateTag();
        nbt.putBoolean("IsCaptured", captured);
    }

    /**
     * Check if this item has been "captured" from an entity
     */
    public static boolean isCaptured(ItemStack stack) {
        CompoundTag nbt = stack.getTag();
        return nbt != null && nbt.contains(BODY_COLOR_TAG);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!level.isClientSide) {
            BlockPos pos = context.getClickedPos();
            Direction face = context.getClickedFace();
            BlockPos spawnPos = pos.relative(face);

            // Check if the position is valid for spawning
            if (level.getBlockState(spawnPos).isAir() &&
                    level.getBlockState(spawnPos.below()).isSolid()) {

                // Create and spawn baby entity
                DenDenMushiEntity entity = ModEntities.DEN_DEN_MUSHI.get().create(level);
                if (entity != null) {
                    entity.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);

                    // Apply stored data from item (includes setting baby = true)
                    applyToEntity(context.getItemInHand(), entity);

                    level.addFreshEntity(entity);

                    // Play placement sound (higher pitch for baby)
                    level.playSound(null, spawnPos.getX(), spawnPos.getY(), spawnPos.getZ(),
                            SoundEvents.SLIME_SQUISH_SMALL, SoundSource.BLOCKS, 0.5f,
                            1.2f + level.random.nextFloat() * 0.4f); // Higher pitch

                    // Remove item from player's hand
                    if (!context.getPlayer().isCreative()) {
                        context.getItemInHand().shrink(1);
                    }

                    return InteractionResult.SUCCESS;
                }
            }
        }
        return InteractionResult.PASS;
    }

    /**
     * Add tooltip showing colors and capture status
     */
    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        if (isCaptured(stack)) {
            tooltip.add(Component.literal("Captured Baby Den Den Mushi")
                    .withStyle(ChatFormatting.DARK_GRAY));

            if (flag.isAdvanced()) {
                // Show body color as hex
                int bodyColor = getBodyColor(stack);
                tooltip.add(Component.literal("Body: #" +
                                String.format("%06X", bodyColor).toUpperCase())
                        .withStyle(ChatFormatting.DARK_GRAY));

                // Show shell color by dye name
                int shellColorId = getShellColor(stack);
                DyeColor shellColor = DyeColor.byId(shellColorId);
                tooltip.add(Component.literal("Shell: " +
                                shellColor.getName().substring(0, 1).toUpperCase() +
                                shellColor.getName().substring(1))
                        .withStyle(ChatFormatting.DARK_GRAY));
            }
        } else {
            tooltip.add(Component.literal("Wild Baby Den Den Mushi")
                    .withStyle(ChatFormatting.DARK_GRAY));
            tooltip.add(Component.literal("Right-click to place")
                    .withStyle(ChatFormatting.DARK_GRAY));
        }
    }

    /**
     * Get shell variant name for model/texture purposes
     */
    public String getShellVariant(ItemStack stack) {
        int shellColorId = getShellColor(stack);
        DyeColor shellColor = DyeColor.byId(shellColorId);
        return "baby_den_den_mushi_shell_" + shellColor.getName();
    }
}